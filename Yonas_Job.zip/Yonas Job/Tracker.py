class Tracker:
    def __init__(self):
        self.employeeList = []
        self.currentShift = []
        self.jobList = ["board", "dining", "cashier", "expo", "basket", "bird", "toast"]
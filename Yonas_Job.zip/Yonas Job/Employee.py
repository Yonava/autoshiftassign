class Employee:
    def __init__(self, name, board, dining, cashier, expo, basket, bird, toast):
        self.name = name
        self.board = board
        self.dining = dining
        self.cashier = cashier
        self.expo = expo 
        self.basket = basket
        self.bird = bird
        self.toast = toast
        self.currentJob = "No Job Assigned"
    
    def isValid(self):
        if sum(self.board, self.dining, self.cashier, self.expo, self.basket, self.bird, self.toast) == 0:
            return False
        return True
    
    def display(self):
        print(f"Name: {self.name}, Scores: {self.board, self.dining, self.cashier, self.expo, self.basket, self.bird, self.toast, self.currentJob} | ", end="")

    def unAssign(self):
        self.currentJob = "No Job Assigned"
    
    def canDoCurrentJob(self):
        if self.currentJob == "board": return self.board != 0
        if self.currentJob == "dining": return self.dining != 0
        if self.currentJob == "cashier": return self.cashier != 0
        if self.currentJob == "expo": return self.expo != 0
        if self.currentJob == "basket": return self.basket != 0
        if self.currentJob == "bird": return self.bird != 0
        if self.currentJob == "toast": return self.toast != 0
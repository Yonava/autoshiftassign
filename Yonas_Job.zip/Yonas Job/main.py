'''
TE 
Job assigner for Yona's Raising Canes Job O.O
'''
import Employee
import Tracker
import random

def add(data):
    data.employeeList.append(Employee.Employee(
        input("Employee name: "),
        int(input("Board rating: ")),
        int(input("Dining Room rating: ")),
        int(input("Cashier rating: ")),
        int(input("Expo rating: ")),
        int(input("Basket rating: ")),
        int(input("Bird rating: ")),
        int(input("Toast rating: "))
    ))

def sort(toSort, sortBy):
    if sortBy == "name": return sorted(toSort, key=lambda x: x.name)
    if sortBy == "board": return sorted(toSort, key=lambda x: x.board, reverse=True)
    if sortBy == "dining": return sorted(toSort, key=lambda x: x.dining, reverse=True)
    if sortBy == "cashier": return sorted(toSort, key=lambda x: x.cashier, reverse=True)
    if sortBy == "expo": return sorted(toSort, key=lambda x: x.expo, reverse=True)
    if sortBy == "basket": return sorted(toSort, key=lambda x: x.basket, reverse=True)
    if sortBy == "bird": return sorted(toSort, key=lambda x: x.bird, reverse=True)
    if sortBy == "toast": return sorted(toSort, key=lambda x: x.toast, reverse=True)
    return print("Error! Contact developer. CODE: 001")

def remove(data):
    toRemove = input("Name of employee to be removed")
    for e in data.employeeList:
        if e.name.lower() == toRemove.lower():
            data.employeeList.remove(e)

def getJobs(jobList):
    jobs = []
    for j in jobList:
        n = int(input(f"How many {j}? "))
        for i in range(n):
            jobs.append(j)
    return jobs

def unAssign(data):
    for e in data.employeeList:
        if e not in data.currentShift:
            e.unAssign()

def assign(data):
    itCycles = 0
    data.currentShift = []
    jobs = getJobs(data.jobList)
    random.shuffle(jobs)
    possibleShift = False
    tmpList = data.employeeList.copy()
    for e in tmpList:
        if not e.isValid:
            tmpList.remove(e)

    if len(tmpList) < len(jobs):
        return print("Not enough employees to fill these positions")
        
    tmpListReset = tmpList.copy()
    while not possibleShift:
        untrained = 0
        tmpList = tmpListReset

        for j in jobs:
            if len(tmpList) > 0:
                tmpList = sort(tmpList, j)
                tmpList[0].currentJob = j
                data.currentShift.append(tmpList.pop(0))

        for e in tmpList:
            if not e.canDoCurrentJob():
                untrained += 1
                
        if untrained == 0:
            # and input("Do you want to re-generate? (y/n) ") != "y"
            possibleShift = True

        itCycles += 1
        if itCycles > 1000:
            return print("No shifts possible")

    unAssign(data)
    display(data.currentShift)

def display(listType):
    for e in listType:
        e.display()
    print()

def main():
    data = Tracker.Tracker()
    doExit = False
    while not doExit:
        selection = input("What do you want to do? (a)dd employee to the database, (r)emove employee from the database, a(s)sign crew to a shift, (d)isplay all employees, (e)xit...")
        if selection == "a": add(data)
        elif selection == "r": remove(data)
        elif selection == "s": assign(data)
        elif selection == "d": display(data.employeeList)
        elif selection == "e": doExit = True
        else: print("Selection not recognized")

main()
